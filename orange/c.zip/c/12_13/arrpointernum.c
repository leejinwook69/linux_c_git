#include <stdio.h>

int main(void)
{
	int arr[3]={1, 2, 3};
	
	printf("%p", arr);
	return 0;
}