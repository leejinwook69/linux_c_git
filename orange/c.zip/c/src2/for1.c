#include <stdio.h>

int main(void)
{
	int num=2;
	
	for (num=8; num<10; num++)
		printf("hello world\n");
	
	return 0;
}