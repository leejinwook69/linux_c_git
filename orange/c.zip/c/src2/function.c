#include <stdio.h>

int add(int num1,int num2)
{
	return num1+num2;
}
int main(void)
{
	printf("%d", add(1,2));
	return 0;
}

int add(int n1, int n2)
{
	return n1-n2;
}