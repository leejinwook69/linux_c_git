#include <stdio.h>

int main(void)
{
	int a = 3;
	int b = 2;
	
	if(a == b)
		printf("같다\n");
	else
		printf("다르다\n");
	
	return 0;
}