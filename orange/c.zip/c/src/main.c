#include <stdio.h>

int main (void)
{
	printf("%e", 12309309.15152);
	return 0;
	
 }

tprmadl dhffkTek. cndrurwjrdlek dnflwlqdml rkrPdp zms dudgiddl dlTdmf rjt rkxek. ekwnxorwkfkeh tlf themrdms djfak ehlwl dksgsmsep tprmadl 2qo dltkddmfh dhfmsekaus dnflwlqdml alfork qnfxnaudgowlsms rjt rkxek. qnahslaRp whlthdgkek wotn tkatn dksgkrh rhdqn wkf gotj whgdms eogkr rkrh qkfh rnseo rkrh qkfh whfdjq gotj ehs aksgdl qjfdj emfuTdjdi goTsmep 24tkf akrqkwldml tlrldls wlrma sksm rpdladlsk dnpq tjvld emfdp Qkwu qnahsla emddp rltodgksms Rhfdlek. 樹欲靜而風不止 子欲養而親不待. sksms qksemtl tjdrhdgkf rjtdlek.