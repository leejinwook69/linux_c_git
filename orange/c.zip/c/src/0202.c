#include <stdio.h>

int main(void){
	printf("name : name\n");
	printf("address : address\n");
	printf("tel : tel\n");
	return 0;
}