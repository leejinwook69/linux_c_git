#include <stdio.h>

int main(void)
	
{
	int five=0, star=0, zero=0;
	
	while (five<5)
	{
		star=0;
		
		while (star<zero)
		{
			printf("o");
			star++;
		}
		
		
		printf("*\n");
		
		zero++;
		five++;
	}
	return 0;
}