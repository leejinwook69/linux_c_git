#include <stdio.h>

int main(void)
{
	int num1, num2;
	printf("input two integers : ");
	scanf("%d %d", &num1, &num2);
	printf("subtraction : %d \n", num1-num2);
	printf("multiplication : %d \n", num1*num2);
	return 0;
}
