#include <stdio.h>

int main (void)
{
		int num1=3;
	
	//num1 = num1<<3;
	//num1 = num1>>2;
	//printf num1
	
	printf("3 x 8 / 4 = %d\n", num1<<3>>2);
	
	
	return 0;
}