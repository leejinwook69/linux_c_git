#include <stdio.h>

int main(void)
{
	int num=0, n=0;
	printf("input num : ");
		scanf("%d", &num);
	while (n<num)
	{
		printf("Hello world\n");
		n++;
	}
	return 0;
}