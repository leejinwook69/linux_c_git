#include <stdio.h>

int main(void)
{
	int ch; 
	printf("input ascii code of alphabet : \n");
	scanf("%d", &ch);
	printf("%c\n", ch);
	return 0;
}