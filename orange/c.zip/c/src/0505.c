#include <stdio.h>

int main(void)
{
	char ch1;
	printf("input an alphabet : \n");
	scanf("%c", &ch1);
	printf("%d\n", ch1);
	return 0;
}