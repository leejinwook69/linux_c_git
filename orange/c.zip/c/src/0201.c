#include <stdio.h>

int main (void) {
	printf("leejinwook\nlee jin wook\nlee   jin   wook\n");
		return 0;
}